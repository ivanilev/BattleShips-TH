//Table Cell Element
class Element{
    constructor(x,y){
        this.position = {x,y};
        this.isHit = false;
        this.isShipHere = false;
    };
}